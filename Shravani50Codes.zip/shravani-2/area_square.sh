#!/bin/bash
echo "Enter side length:"
read side
area=$((side * side))
echo "Area of square: $area"

