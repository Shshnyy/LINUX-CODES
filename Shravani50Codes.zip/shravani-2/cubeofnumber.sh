#!/bin/bash
echo "Enter a number:"
read num
cube=$((num * num * num))
echo "Cube of $num is $cube"

