#!/bin/bash
echo "Current Date and Time: $(date)"

