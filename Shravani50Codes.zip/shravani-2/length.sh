#!/bin/bash

read -p "Enter a string: " str

echo "Length of the string: ${#str}"

