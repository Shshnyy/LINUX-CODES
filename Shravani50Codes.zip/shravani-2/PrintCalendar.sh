#!/bin/bash
echo "Enter year:"
read year
cal $year

