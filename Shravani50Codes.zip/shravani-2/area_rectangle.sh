#!/bin/bash
echo "Enter length:"
read length
echo "Enter width:"
read width
area=$((length * width))
echo "Area of rectangle: $area"

